import * as THREE from 'three';
import {InputManager} from './InputManager.js';
import {SaveSystem} from './SaveSystem.js';
import {SurvivalSystem} from '../survival/SurvivalSystem.js';
import {HUD} from '../ui/HUD.js';
import {MobileControls} from '../ui/MobileControls.js';
import {IntroCinematic} from '../cinematic/IntroCinematic.js';
import {Inventory} from '../inventory/Inventory.js';
import {CreatureSystem} from '../creatures/CreatureSystem.js';
import {ShipSystem} from '../ship/ShipSystem.js';
import {BaseSystem} from '../base/BaseSystem.js';
import {WorldSystem} from '../world/WorldSystem.js';
import {AudioSystem} from '../core/AudioSystem.js';

export class Game{
 constructor(){
  this.scene=new THREE.Scene();
  this.camera=new THREE.PerspectiveCamera(72,innerWidth/innerHeight,.05,600);
  this.renderer=new THREE.WebGLRenderer({canvas:document.querySelector('#game'),antialias:true,powerPreference:'high-performance'});
  this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));this.renderer.setSize(innerWidth,innerHeight);this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.12;this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  this.clock=new THREE.Clock();this.paused=true;this.started=false;
  this.player={pos:new THREE.Vector3(0,3,14),yaw:0,pitch:0,onGround:true,jumpT:0,moving:false,sprinting:false};
  this.state=this.defaultState();
  this.input=new InputManager(this);this.save=new SaveSystem(this);this.survival=new SurvivalSystem(this);this.hud=new HUD(this);this.controls=new MobileControls(this);this.inventory=new Inventory(this);this.creatures=new CreatureSystem(this);this.ship=new ShipSystem(this);this.base=new BaseSystem(this);this.world=new WorldSystem(this);this.audio=new AudioSystem(this);this.cinematic=new IntroCinematic(this);
  this.flashlight=new THREE.SpotLight(0xdff8ff,0,32,Math.PI/7,.42,1.3);this.flashlight.castShadow=true;this.flashlight.target.position.set(0,0,-14);this.camera.add(this.flashlight,this.flashlight.target);this.scene.add(this.camera);
  this.bindUI();addEventListener('resize',()=>this.resize());
 }
 defaultState(){return {version:'2.0.0',day:1,time:8.5,story:0,objective:'INSPECT THE CRASH SITE',region:'CRASH BASIN',sector:1,weather:'clear',flashlight:false,base:[],discovered:{},quests:{},worldSeed:92741,stats:{kills:0,mined:0,built:0},ship:{oxygen:35,power:10,communication:0}}}
 terrainHeight(x,z){return this.world?.height(x,z)??-2.5}
 bindUI(){const $=id=>document.getElementById(id);
  $('newGame').onclick=()=>this.newGame();$('continueGame').onclick=()=>this.continueGame();$('settingsBtn').onclick=()=>{$('settingsPanel').classList.remove('hidden');this.setPause(true)};
  $('closeSettings').onclick=()=>{$('settingsPanel').classList.add('hidden');this.setPause(false)};$('sens').oninput=e=>this.controls.sensitivity=+e.target.value;$('quality').onchange=e=>this.applyQuality(e.target.value);$('skipCine').onclick=()=>this.cinematic.skip();
  $('closeInventory').onclick=()=>$('inventoryPanel').classList.add('hidden');$('closeMissions').onclick=()=>$('missionPanel').classList.add('hidden');$('closeScanner').onclick=()=>$('scannerOverlay').classList.add('hidden');$('closeBuild').onclick=()=>$('buildPanel').classList.add('hidden');
  $('resume').onclick=()=>this.setPause(false);$('saveBtn').onclick=()=>{this.save.save();this.hud.toast('EXPEDITION SAVED')};$('pauseSettings').onclick=()=>{$('pausePanel').classList.add('hidden');$('settingsPanel').classList.remove('hidden')};
  $('mainMenu').onclick=()=>{this.setPause(true);$('pausePanel').classList.add('hidden');$('hud').classList.add('hidden');$('menu').classList.remove('hidden')};$('restoreBtn').onclick=()=>{this.save.load();$('deathPanel').classList.add('hidden');$('hud').classList.remove('hidden');this.paused=false};$('deathMenu').onclick=()=>{$('deathPanel').classList.add('hidden');$('hud').classList.add('hidden');$('menu').classList.remove('hidden')};
  $('craftOxygen').onclick=()=>this.inventory.craft('oxygenTank');$('craftMedkit').onclick=()=>this.inventory.craft('medkit');$('craftBeacon').onclick=()=>this.inventory.craft('beacon');$('useWater').onclick=()=>this.inventory.use('water');$('useFood').onclick=()=>this.inventory.use('food');
  $('buildSolar').onclick=()=>this.base.build('solar');$('buildOxygen').onclick=()=>this.base.build('oxygen');$('buildStorage').onclick=()=>this.base.build('storage');$('buildWall').onclick=()=>this.base.build('wall');$('buildBeacon').onclick=()=>this.base.build('beacon');
  document.querySelectorAll('#actions button').forEach(b=>b.addEventListener('click',()=>this.action(b.dataset.action)));
 }
 applyQuality(q){const p=q==='low'?.8:q==='high'?1.8:1.35;this.renderer.setPixelRatio(Math.min(devicePixelRatio,p));this.hud.toast('GRAPHICS: '+q.toUpperCase())}
 newGame(){this.save.clear();this.state=this.defaultState();this.inventory.reset();this.survival.reset();this.ship.reset();this.base.reset();this.creatures.reset();this.player.pos.set(0,this.terrainHeight(0,14)+1.7,14);this.player.yaw=0;this.player.pitch=0;document.querySelector('#menu').classList.add('hidden');document.querySelector('#hud').classList.remove('hidden');this.started=true;this.paused=true;this.audio.start();this.cinematic.play()}
 continueGame(){document.querySelector('#menu').classList.add('hidden');document.querySelector('#hud').classList.remove('hidden');if(!this.save.load()){this.state=this.defaultState();this.inventory.reset();this.survival.reset()}this.started=true;this.paused=false;this.audio.start();this.hud.toast('EXPEDITION RESTORED')}
 setPause(v){this.paused=v;document.querySelector('#pausePanel').classList.toggle('hidden',!v)}
 die(){this.paused=true;document.querySelector('#deathPanel').classList.remove('hidden');this.save.save();this.audio.stop()}
 findInteractable(){const p=this.player.pos;const items=[];const shipD=p.distanceTo(this.ship.position);if(shipD<7)items.push({type:'ship',title:'WRECKED LANDER',text:this.state.story<1?'Inspect the crash damage':'Repair or manage life support'});const beaconD=p.distanceTo(this.base.beacon.position);if(beaconD<6)items.push({type:'beacon',title:'EMERGENCY BEACON',text:'Inspect the unknown transmission'});const node=this.world.nearestResource(p,4);if(node)items.push({type:'resource',node,title:node.kind.toUpperCase(),text:'Mine resource'});const cave=this.world.nearestCave(p,5);if(cave)items.push({type:'cave',cave,title:'CAVE ENTRANCE',text:'Enter the cavern'});return items[0]||null}
 interact(){const o=this.findInteractable();if(!o)return this.hud.toast('NOTHING WITHIN REACH');
  if(o.type==='resource')return this.world.mine(o.node);
  if(o.type==='cave'){this.world.enterCave(o.cave);return}
  if(o.type==='ship'){if(this.state.story<1){this.state.story=1;this.state.objective='COLLECT 3 TITANIUM + 2 COPPER';this.inventory.add('titanium',3);this.inventory.add('copper',2);this.hud.toast('LIFE SUPPORT DAMAGE CONFIRMED')}else if(!this.ship.repaired)this.ship.repairOxygen();else this.hud.toast('SHIP SYSTEMS ONLINE')}
  if(o.type==='beacon'){this.state.story=Math.max(this.state.story,2);this.state.objective='FOLLOW THE UNKNOWN SIGNAL';this.state.quests.signal=true;this.hud.toast('SIGNAL LOCKED • SCANNER UPDATED')}
 }
 action(a){if(!this.started)return;this.audio.start();if(a==='jump')this.input.jump=true;if(a==='interact')this.interact();if(a==='mine')this.interact();if(a==='flashlight'){this.state.flashlight=!this.state.flashlight;this.flashlight.intensity=this.state.flashlight?6:0;this.hud.toast(this.state.flashlight?'FLASHLIGHT ON':'FLASHLIGHT OFF')}if(a==='scanner')this.scan();if(a==='inventory')document.querySelector('#inventoryPanel').classList.remove('hidden');if(a==='missions')this.showMissions();if(a==='build')document.querySelector('#buildPanel').classList.remove('hidden');if(a==='pause')this.setPause(true)}
 scan(){const panel=document.querySelector('#scannerOverlay'),bar=document.querySelector('#scanBar'),txt=document.querySelector('#scanText'),target=document.querySelector('#scanTarget');panel.classList.remove('hidden');bar.style.width='0%';txt.textContent='Sampling electromagnetic spectrum...';target.textContent='SCANNING';let p=0;clearInterval(this.scanTimer);this.scanTimer=setInterval(()=>{p+=10;bar.style.width=p+'%';if(p>=100){clearInterval(this.scanTimer);target.textContent='ANALYSIS COMPLETE';txt.textContent=this.world.scanReport(this.player.pos);this.hud.toast('SCAN COMPLETE')}} ,55)}
 showMissions(){const l=document.querySelector('#missionList'),p=document.querySelector('#missionPanel');p.classList.remove('hidden');const a=[['01','SURVIVE THE CRASH','Inspect the wrecked lander.',this.state.story>=1],['02','RESTORE LIFE SUPPORT','Repair oxygen with titanium and copper.',this.ship.repaired],['03','BUILD A BEACON','Craft and deploy a beacon.',!!this.state.quests.beaconBuilt],['04','TRACE THE SIGNAL','Find the anomalous transmission.',!!this.state.quests.signal],['05','DESCEND','Discover the underground cave network.',!!this.state.quests.cave],['06','FIRST CONTACT','Survive an encounter with the apex lifeform.',this.state.stats.kills>=1],['07','LEAVE NO TRACE','Power the launch sequence.',!!this.state.quests.launch]];l.innerHTML=a.map(x=>`<div class="mission ${x[3]?'done':''}"><b>${x[0]} — ${x[1]}</b><span>${x[2]}</span></div>`).join('')}
 update(dt){if(this.paused)return;this.state.time+=dt*.018;if(this.state.time>=24){this.state.time-=24;this.state.day++}this.world.update(dt);this.survival.update(dt);this.input.update(dt);this.creatures.update(dt);this.base.update(dt);this.ship.update(dt);this.hud.update();this.camera.position.copy(this.player.pos);this.camera.rotation.order='YXZ';this.camera.rotation.y=this.player.yaw;this.camera.rotation.x=this.player.pitch;this.camera.fov=72+(this.player.sprinting?2:0);this.camera.updateProjectionMatrix();if(Math.random()<dt*.002)this.save.save()}
 frame(){requestAnimationFrame(()=>this.frame());const dt=Math.min(this.clock.getDelta(),.05);this.update(dt);this.renderer.render(this.scene,this.camera)}
 start(){this.frame()}resize(){this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();this.renderer.setSize(innerWidth,innerHeight)}
}
