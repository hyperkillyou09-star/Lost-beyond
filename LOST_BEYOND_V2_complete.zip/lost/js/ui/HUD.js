export class HUD{
 constructor(g){this.g=g;this.toastTimer=0}
 update(){
  const v=this.g.survival.values;
  for(const k of ["health","oxygen","hydration","hunger","energy"]){document.getElementById(k).textContent=Math.round(v[k]);document.getElementById(k+"Bar").style.width=Math.max(0,v[k])+"%"}
  const temp=v.temp;document.getElementById("temp").textContent=temp>78?"HOT":temp<22?"COLD":"NORMAL";document.getElementById("tempBar").style.width=temp+"%";
  document.getElementById("objectiveText").textContent=this.g.state.objective;
  const h=Math.floor(this.g.state.time),m=Math.floor((this.g.state.time%1)*60);
  document.getElementById("timePill").textContent=`DAY ${String(this.g.state.day).padStart(2,"0")} • ${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
  document.getElementById("weatherPill").textContent=this.g.world.weather.toUpperCase();
  document.getElementById("location").innerHTML=`AURELIA-9<br><span>${this.g.world.region.toUpperCase()} • SECTOR ${String(this.g.world.sector).padStart(2,"0")}</span>`;
  const deg=(THREE_DEG(this.g.player.yaw)+360)%360;document.getElementById("compassDeg").textContent=String(Math.round(deg)).padStart(3,"0")+"°";
  this.updatePrompt();
  if(this.toastTimer>0){this.toastTimer-=.016;if(this.toastTimer<=0)document.getElementById("toast").style.opacity=0}
 }
 updatePrompt(){
  const p=this.g.findInteractable(),box=document.getElementById("interactionPrompt");
  if(p){box.classList.remove("hidden");document.getElementById("promptTitle").textContent=p.title;document.getElementById("promptText").textContent=p.text}
  else box.classList.add("hidden");
 }
 toast(t){const e=document.getElementById("toast");e.textContent=t;e.style.opacity=1;this.toastTimer=2.6}
}
function THREE_DEG(r){return r*180/Math.PI}