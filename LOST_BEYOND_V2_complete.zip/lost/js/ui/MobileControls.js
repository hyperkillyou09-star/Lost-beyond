export class MobileControls{
 constructor(g){this.g=g;this.sensitivity=1;this.running=false;this.joy=document.querySelector("#joystick");this.stick=document.querySelector("#stick");this.look=document.querySelector("#lookZone");this.bindJoy();this.bindLook();this.bindActionHold()}
 bindJoy(){
  let active=false,cx=0,cy=0;
  const point=e=>e.touches?e.touches[0]:e;
  const start=e=>{active=true;const p=point(e),r=this.joy.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;move(p)};
  const move=e=>{if(!active)return;const p=point(e);let dx=p.clientX-cx,dy=p.clientY-cy;const max=48,l=Math.hypot(dx,dy);if(l>max){dx*=max/l;dy*=max/l}this.stick.style.transform=`translate(${dx}px,${dy}px)`;this.g.input.moveX=dx/max;this.g.input.moveY=-dy/max;this.running=Math.hypot(this.g.input.moveX,this.g.input.moveY)>.82};
  const end=()=>{active=false;this.stick.style.transform="";this.g.input.moveX=0;this.g.input.moveY=0;this.running=false};
  this.joy.addEventListener("touchstart",e=>{e.preventDefault();start(e)},{passive:false});
  this.joy.addEventListener("touchmove",e=>{e.preventDefault();move(e)},{passive:false});
  this.joy.addEventListener("touchend",end,{passive:true});this.joy.addEventListener("touchcancel",end,{passive:true});
 }
 bindLook(){
  let last=null;
  this.look.addEventListener("touchstart",e=>{last={x:e.touches[0].clientX,y:e.touches[0].clientY}},{passive:true});
  this.look.addEventListener("touchmove",e=>{if(!last)return;const p=e.touches[0],dx=p.clientX-last.x,dy=p.clientY-last.y;this.g.player.yaw-=dx*.0048*this.sensitivity;this.g.player.pitch-=dy*.0033*this.sensitivity;this.g.player.pitch=Math.max(-1.18,Math.min(1.18,this.g.player.pitch));last={x:p.clientX,y:p.clientY}},{passive:true});
  this.look.addEventListener("touchend",()=>last=null,{passive:true});this.look.addEventListener("touchcancel",()=>last=null,{passive:true});
 }
 bindActionHold(){
  const run=document.querySelector('[data-action="sprint"]');
  run.addEventListener("touchstart",e=>{e.preventDefault();this.running=true},{passive:false});
  ["touchend","touchcancel"].forEach(ev=>run.addEventListener(ev,()=>this.running=false,{passive:true}));
 }
}