import { Game } from "./core/Game.js";
const game=new Game();window.LOST_BEYOND=game;game.start();