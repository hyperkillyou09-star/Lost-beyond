# LOST BEYOND V2 DESIGN

A mobile-first sci-fi survival exploration game on Aurelia-9. The player survives a crash, repairs life support, explores multiple biomes, mines resources, builds a small base, discovers caves, scans anomalies and follows an unknown signal.

## Design pillars
- Exploration first
- Readable mobile HUD
- Strong atmosphere
- Short interactions, long-term progression
- Every system modular and replaceable

## Controls
Left joystick = move. Right half = look. Buttons = jump, run, use, light, scan, bag, log, build, pause.
Desktop fallback: WASD, mouse/touch look, Space, E, F, I, B, R.

## Persistence
SaveSystem stores game state, player transform, survival, inventory, repaired ship and structures in localStorage key `lost_beyond_save_v2`.

## Handoff rule
When another AI continues this project, read this file, GAME_STATE.md and CHANGELOG.md before changing code. Preserve the public IDs in index.html and the module boundaries.
