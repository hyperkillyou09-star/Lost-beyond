# LOST BEYOND V2

Open `index.html` in a static web host. GitHub Pages works without a build step.

### iPhone
Open the deployed URL in Safari → Share → Add to Home Screen. The PWA shell can then launch fullscreen.

### Continuing with another AI
Upload the whole project and tell the AI to read `GAME_STATE.md`, `GAME_DESIGN.md` and `CHANGELOG.md` first. Do not replace the module structure unless necessary.
