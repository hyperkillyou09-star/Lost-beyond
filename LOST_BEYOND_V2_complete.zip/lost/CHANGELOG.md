# CHANGELOG

## V2.0.0
- Rebuilt world generation and atmosphere.
- Added biome system and sector HUD.
- Added 3000+ visible stars and distant celestial bodies.
- Added mining and resource nodes.
- Added cave entrances.
- Added base construction system.
- Added oxygen generator, storage, solar and beacon structures.
- Added consumable inventory actions.
- Added hostile alien AI and damage.
- Added mission chain and scanner reports.
- Added PWA manifest/service worker.
- Added AudioSystem and mobile-first controls.
- Upgraded save schema to V2.
